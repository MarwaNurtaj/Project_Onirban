@extends('website.home.welcome')
@section('contents')
<section class="section" id='section_main'>
        <div class="row">
            <!-- <div class="col-sm-12">
                <div class="user-handler-icon">
                    <i class="fas fa-user-cog"></i>
                </div>
            </div> -->

            <div class="col-sm-12 ">
                <h1 class="text-dark h1">Welcome to the place where You can</h1>
            </div>
            <div class="col-sm-12 ">
                <h1>
                    <span class="text-white h2">
                        Enter your information, seamlessly explore, edit, and download your data.
                    </span>
                </h1>
            </div>
        </div>
    </section>
    @endsection