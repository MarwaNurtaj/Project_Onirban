
<?php $__env->startSection('page'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card mb-3">
            <div class="card-header">
                <div class="row">
                    <div class="col-md-8 card_title_part">
                        <i class="fab fa-gg-circle"></i>All active User Information
                    </div>
                    <div class="col-md-4 card_button_part">
                        <a href="<?php echo e(url('dashboard/user/add')); ?>" class="btn btn-sm btn-dark"><i
                                class="fas fa-plus-circle"></i>Add User</a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <table class="table table-bordered table-striped table-hover custom_table">
                    <thead class="table-dark">
                        <tr>
                            <th>User Id</th>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Email</th>
                            <th>Status</th>
                            <th>Role</th>
                            <th>Photo</th>
                            <th>Manage</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $allData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($data->id); ?></td>
                            <td><?php echo e($data->name); ?></td>
                            <td><?php echo e($data->last_name); ?></td>
                            <td><?php echo e($data->email); ?></td>
                            <td><span class="badge bg-primary">
                                    <?php if($data->user_status == 1): ?>
                                    Active
                                    <?php endif; ?>
                                </span></td>
                            <td class="text-capitalize"><?php echo e($data->roleInfo->role_name); ?></td>
                            <td>
                                <?php if(!empty($data->photo)): ?>
                                <img src="<?php echo e(asset('contents/admin/uploads/' . $data->photo)); ?>"
                                    style="height:50px; width:auto;" alt="Profile Picture">
                                <?php else: ?>
                                <img src="<?php echo e(asset('contents/admin/images/avatar.png')); ?>"
                                    style="height:50px; width:auto;" alt="Profile Picture">
                                <?php endif; ?>

                            </td>
                            <td>
                                <div class="btn-group btn_group_manage" role="group">
                                    <button type="button" class="btn btn-sm btn-dark dropdown-toggle"
                                        data-bs-toggle="dropdown" aria-expanded="false">Manage</button>
                                    <ul class="dropdown-menu">
                                        <li><a class="dropdown-item"
                                                href="<?php echo e(url('dashboard/user/view/'.$data->user_slug)); ?>">View</a></li>
                                        <li><a class="dropdown-item"
                                                href="<?php echo e(url('dashboard/user/edit/'.$data->user_slug)); ?>">Edit</a></li>
                                        <li> <?php if($data->user_status == 1): ?>
                                            <a href="<?php echo e(url('dashboard/user/de_status', $data->id)); ?>"
                                                class="dropdown-item"> Deactivate User</a>
                                            <?php endif; ?>
                                        </li>
                                    </ul>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                <div class="btn-group" role="group" aria-label="Button group">

                    <a href="<?php echo e(url('admin/user/pdf')); ?>"
                         class="btn btn-sm btn-dark">PDF</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project_Onirban\resources\views/admin/user/all.blade.php ENDPATH**/ ?>