<?php $__env->startSection('logForms'); ?>
<div class="login-page bg-dark ">
    <div class="container">
        <div class="row">
            <div class="col-lg-10 offset-lg-1">
                <h3 class="mb-3 text-light">Verify Now</h3>
                <div class="bg-white shadow rounded">
                    <div class="row">
                        <div class="col-md-7 pe-0">
                            <div class="form-left h-100 py-5 px-5">

                                <div class="col-12">
                                    <p><?php echo e(__('Thanks for signing up! Before getting started, could you verify your email 
                                                address by clicking on the link we just emailed to you? If you didn\'t receive the email,
                                                 we will gladly send you another.')); ?></p>

                                    <?php if(session('status') == 'verification-link-sent'): ?>
                                    <div class="mb-4 font-medium text-sm text-green-600 dark:text-green-400">
                                        <?php echo e(__('A new verification link has been sent to the email address you provided 
                                                        during registration.')); ?>

                                    </div>
                                    <?php endif; ?>
                                </div>
                                <div class="row g-4 mt-2">
                                    <div class="col-sm-12">

                                        <form method="POST" action="<?php echo e(route('password.email')); ?>" class="row g-4">
                                            <?php echo csrf_field(); ?>
                                            <div class="col-12">
                                                <label>Email<span class="text-danger">*</span></label>
                                                <div class="input-group">
                                                    <div class="input-group-text"><i class="fas fa-user"></i></div>
                                                    <input id="email" class="block mt-1 w-full" type="email"
                                                        name="email" :value="old('email')" required autofocus>
                                                </div>
                                                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('email'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('email')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                            </div>

                                             <div class="flex items-center justify-center mt-4 col-12">
                                               <button type="submit "
                                                class="btn btn-primary px-4  "><?php echo e(__('Email Password Reset Link')); ?></button>

                                            </div>
                                        </form>
                                    </div>

                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('website.includesFolder.logNavbarFooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project_Onirban\resources\views/auth/forgot-password.blade.php ENDPATH**/ ?>