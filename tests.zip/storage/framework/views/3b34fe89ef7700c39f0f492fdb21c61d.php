
<?php $__env->startSection('page'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card mb-3">
            <div class="card-header">
                <div class="row">
                    <div class="col-md-8 card_title_part">
                        <i class="fab fa-gg-circle"></i>View User Information
                    </div>
                    <div class="col-md-4 card_button_part">
                        <a href="<?php echo e(url('dashboard/user/edit/'.$data->user_slug)); ?>" class="btn btn-sm btn-dark">
                            <i class="fas fa-th"></i>Edit
                            User</a>
                    </div>
                </div>
            </div>
            <div class="card-body">
            <div class="row">
                        <div class="col-md-2"></div>
                        <div class="col-md-8">
                            <?php if(Session::has('success')): ?>
                            <div class="alert alert-success alert_success" role="alert">
                                <strong>Success!</strong> <?php echo e(Session::get('success')); ?>

                            </div>
                            <?php endif; ?>
                            <?php if(Session::has('error')): ?>
                            <div class="alert alert-danger alert_error" role="alert">
                                <strong>Opps!</strong> <?php echo e(Session::get('error')); ?>

                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-2"></div>
                    </div>
                <div class="row">
                    <div class="col-md-2"></div>
                    <div class="col-md-8">
                        <table class="table table-bordered table-striped table-hover custom_view_table">
                            <tr>
                                <td>First Name</td>
                                <td>:</td>
                                <td><?php echo e($data->name); ?></td>
                            </tr>
                            <tr>
                                <td>Last Name</td>
                                <td>:</td>
                                <td><?php echo e($data->last_name); ?></td>
                            </tr>
                            <tr>
                                <td>Email</td>
                                <td>:</td>
                                <td><?php echo e($data->email); ?></td>
                            </tr>
                            <tr>
                                <td>Status</td>
                                <td>:</td>
                                <td><?php echo e($data->user_status); ?></td>
                            </tr>
                            <tr>
                                <td>User Role</td>
                                <td>:</td>
                                <td><?php echo e($data->user_role); ?></td>
                            </tr>
                            <tr>
                                <td>Create Date</td>
                                <td>:</td>
                                <td><?php echo e($data->created_at->format('d-m-Y | h:i:s A')); ?></td>
                            </tr>
                            <?php if($data->email_verified_at!=NULL): ?>
                            <tr>
                                <td>Email Verified At</td>
                                <td>:</td>
                                <td><?php echo e($data->email_verified_at); ?></td>
                            </tr>
                            <?php else: ?>
                            <tr>
                                <td>Email Verified At</td>
                                <td>:</td>
                                <td class="danger">Not Verified</td>
                            </tr>
                            <tr>
                                <td>Resend Verify Email</td>
                                <td>:</td>
                                <td>
                                    <form method="POST" action="<?php echo e(route('verification.send')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-primary">
                                            <?php echo e(__('Resend Verification Email')); ?>

                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php endif; ?>
                            
                            <?php if($data->updated_at!=''): ?>
                            <tr>
                                <td>Edited At</td>
                                <td>:</td>
                                <td><?php echo e($data->updated_at->format('d-m-Y | h:i:s A')); ?></td>
                            </tr>
                            <?php endif; ?>
                            <tr>
                                <td>Photo</td>
                                <td>:</td>
                                <td>
                                    <?php if(!empty($data->photo)): ?>                           
                                        <img src="<?php echo e(asset('contents/admin/uploads/' . $data->photo)); ?>"
                                            alt="Profile Picture">                       
                                    <?php else: ?>                                    
                                        <img src="<?php echo e(asset('contents/admin/images/avatar.png')); ?>" class="img200"
                                            alt="Profile Picture">
                                    <?php endif; ?>
                                 
                                </td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-md-2"></div>
                </div>
            </div>
            <div class="card-footer">
                <div class="btn-group" role="group" aria-label="Button group">
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project_Onirban\resources\views/admin/user/view.blade.php ENDPATH**/ ?>