
<?php $__env->startSection('contents'); ?>
<section class="section" id='section_main'>
        <div class="row">
            <!-- <div class="col-sm-12">
                <div class="user-handler-icon">
                    <i class="fas fa-user-cog"></i>
                </div>
            </div> -->

            <div class="col-sm-12 ">
                <h1 class="text-dark h1">Welcome to the place where You can</h1>
            </div>
            <div class="col-sm-12 ">
                <h1>
                    <span class="text-white h2">
                        Enter your information, seamlessly explore, edit, and download your data.
                    </span>
                </h1>
            </div>
        </div>
    </section>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('website.home.welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project_Onirban\resources\views/website/home/main.blade.php ENDPATH**/ ?>