<?php $__env->startSection('logForms'); ?>
<div class="login-page bg-dark ">
    <div class="container">
        <div class="row">
            <div class="col-lg-10 offset-lg-1">
                <h3 class="mb-3 text-light">Verify Now</h3>
                <div class="bg-white shadow rounded">
                    <div class="row">
                        <div class="col-md-7 pe-0">
                            <div class="form-left h-100 py-5 px-5">

                                <div class="col-12">
                                    <p><?php echo e(__('Thanks for signing up! Before getting started, could you verify your email 
                                                address by clicking on the link we just emailed to you? If you didn\'t receive the email,
                                                 we will gladly send you another.')); ?></p>

                                    <?php if(session('status') == 'verification-link-sent'): ?>
                                    <div class="mb-4 font-medium text-sm text-green-600 dark:text-green-400">
                                        <?php echo e(__('A new verification link has been sent to the email address you provided 
                                                        during registration.')); ?>

                                    </div>
                                    <?php endif; ?>
                                </div>
                                <div class="row g-4 mt-2">
                                    <div class="col-sm-6">
                                        <!-- <p>Didn't get an email?</p> -->
                                        <form method="POST" action="<?php echo e(route('verification.send')); ?>">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-primary">
                                                <?php echo e(__('Resend Verification Email')); ?>

                                            </button>
                                        </form>
                                    </div>

                                    <div class="col-sm-6">
                                        <form method="POST" action="<?php echo e(route('logout')); ?>">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit"
                                                class="btn btn-danger float-end">
                                                <?php echo e(__('Log Out')); ?>

                                            </button>
                                        </form>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="col-md-5 ps-0 d-none d-md-block">
                            <div class="form-right h-100 bg-primary text-white text-center pt-5">
                                <i class="fas fa-user-shield"></i>
                                <h2 class="fs-1"> Verify Now</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.includesFolder.logNavbarFooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project_Onirban\resources\views/auth/verify-email.blade.php ENDPATH**/ ?>