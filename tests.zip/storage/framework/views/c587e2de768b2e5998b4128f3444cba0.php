
<?php $__env->startSection('page'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card mb-3">
            <div class="card-header">
                <div class="row">
                    <div class="col-md-8 card_title_part">
                        <i class="fab fa-gg-circle"></i>All Inactive User Information
                    </div>
                    <div class="col-md-4 card_button_part">
                        <!-- <a href="<?php echo e(url('dashboard/user/add')); ?>" class="btn btn-sm btn-dark"><i class="fas fa-plus-circle"></i>Add User</a> -->
                    </div>
                </div>
            </div>
            <div class="card-body">
                <table class="table table-bordered table-striped table-hover custom_table">
                    <thead class="table-dark">
                        <tr>
                            <th>User Id</th>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Email</th>
                            <th>Status</th>
                            <th>Role</th>
                            <th>Manage</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $allData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($data->id); ?></td>
                            <td><?php echo e($data->name); ?></td>
                            <td><?php echo e($data->last_name); ?></td>
                            <td><?php echo e($data->email); ?></td>
                            <td><span class="badge bg-primary">
                                    <?php if($data->user_status == 0): ?>
                                    Inactive
                                    <?php endif; ?>
                                </span></td>

                            <td class="text-capitalize"><?php echo e($data->roleInfo->role_name); ?></td>

                            <td>
                                <?php if($data->user_status == 0): ?>
                                <a href="<?php echo e(url('dashboard/user/status', $data->id)); ?>" class="btn btn-danger btn-sm"
                                    type="button">Reactive</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project_Onirban\resources\views/admin/user/inactiveUser.blade.php ENDPATH**/ ?>