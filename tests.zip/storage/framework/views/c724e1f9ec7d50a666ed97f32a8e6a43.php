<?php if(auth()->guard()->check()): ?>

<?php $__env->startSection('contents'); ?>

<section class="space-around m-5 p-5">
    <div class="container">
        <div class="row justify-content-center">
            <?php if(Auth::user()->user_status == 0  || Auth::user()->user_status == 1  ): ?>
            <div class="col-md-4 col-12">
                <a href="<?php echo e(url('website/home/view_profile/' . Auth::user()->user_slug)); ?>">
                    <div class="card border_card m-3">
                        <div class="card-img">
                            <img src="<?php echo e(asset('contents/admin/images/view-info.png')); ?>" class="card-img-top" alt="...">
                        </div>
                        <div class="card-body">
                            <p class="card-text card_text">View Your Profile</p>
                        </div>
                    </div>
                </a>
            </div>
            <?php endif; ?>
            <?php if(Auth::user()->user_status == 1): ?>
            <div class="col-md-4 col-12">
                <a href="<?php echo e(url('website/home/edit_profile/' . Auth::user()->user_slug)); ?>">
                    <div class="card border_card m-3">
                        <div class="card-img">
                            <img src="<?php echo e(asset('contents/admin/images/edit-info.png')); ?>" class="card-img-top" alt="...">
                        </div>
                        <div class="card-body">
                            <p class="card-text card_text">Edit Your Profile</p>
                        </div>
                    </div>
                </a>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>
<hr>
<hr>
<hr>
<hr>
<hr>
<hr>

<?php $__env->stopSection(); ?>

<?php endif; ?>
<?php echo $__env->make('website.home.welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project_Onirban\resources\views/website/home/userDashboard.blade.php ENDPATH**/ ?>