
<?php $__env->startSection('page'); ?>


<div class="row">
    <div class="col-md-12 ">
        <form method="POST" action="<?php echo e(url('dashboard/user/update')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="card mb-3">

                <div class="card-header">
                    <div class="row">
                        <div class="col-md-8 card_title_part">
                            <i class="fab fa-gg-circle"></i>User Edit
                        </div>
                        <div class="col-md-4 card_button_part">
                            <a href="<?php echo e(url('dashboard/user')); ?>" class="btn btn-sm btn-dark"><i class="fas fa-th"></i>All
                                User</a>
                        </div>
                    </div>
                </div>

                <div class="card-body">
                    <div class="row">
                        <div class="col-md-2"></div>
                        <div class="col-md-8">
                            <?php if(Session::has('success')): ?>
                            <div class="alert alert-success alert_success" role="alert">
                                <strong>Success!</strong> <?php echo e(Session::get('success')); ?>

                            </div>
                            <?php endif; ?>
                            <?php if(Session::has('error')): ?>
                            <div class="alert alert-danger alert_error" role="alert">
                                <strong>Opps!</strong> <?php echo e(Session::get('error')); ?>

                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-2"></div>
                    </div>
                    <div class="row mb-3 <?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                        <label class="col-sm-3 col-form-label col_form_label">Name<span
                                class="req_star">*</span>:</label>
                        <div class="col-sm-7">
                        <input type="hidden" id="" name="id" value="<?php echo e($data->id); ?>">
                        <input type="hidden" id="" name="slug" value="<?php echo e($data->user_slug); ?>">
                            <input type="text" class="form-control form_control" id="" name="name"
                                value="<?php echo e($data->name); ?>">
                            <?php if($errors->has('name')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('name')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="row mb-3 <?php echo e($errors->has('last_name') ? ' has-error' : ''); ?>">
                        <label class="col-sm-3 col-form-label col_form_label">Last Name :</label>
                        <div class="col-sm-7">
                            <input type="text" class="form-control form_control" id="" name="last_name"
                                value="<?php echo e($data->last_name); ?>">
                            <?php if($errors->has('last_name')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('last_name')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="row mb-3 <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                        <label class="col-sm-3 col-form-label col_form_label">Email<span
                                class="req_star">*</span>:</label>
                        <div class="col-sm-7">
                            <input type="text" class="form-control form_control" id="email" name="email"
                                value="<?php echo e($data->email); ?>">
                            <?php if($errors->has('email')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label class="col-sm-3 col-form-label col_form_label">User Status<span
                                class="req_star">*</span>:</label>
                        <div class="col-sm-4">
                            <input type="number" class="form-control form_control " id="user_status" min="0" max="1"
                                placeholder="Enter 0 for deactivate, 1 for active" name="user_status"
                                value="<?php echo e($data->user_status); ?>">
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label class="col-sm-3 col-form-label col_form_label">User Role<span
                                class="req_star">*</span>:</label>
                        <div class="col-sm-4">
                            <?php
                            $all_role=App\Models\Role::where('role_status',1)->orderBy('role_name','ASC')->get();
                            ?>
                            <select class="form-control form_control text-capitalize" id="" name="role">
                                <option value="">Select Role</option>

                                <?php $__currentLoopData = $all_role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($role->role_id); ?>" <?php if($role->role_id==$data->user_role): ?>
                                    selected <?php endif; ?> class="text-capitalize">
                                    <?php echo e($role->role_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('pic')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('user_role')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row mb-3 <?php echo e($errors->has('pic') ? ' has-error' : ''); ?>">
                        <label class="col-sm-3 col-form-label col_form_label">Photo:</label>
                        <div class="col-sm-4">
                            <input type="file" class="form-control form_control" id="" name="pic">
                            <?php if($errors->has('pic')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('pic')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-2">
                            <?php if(!empty($data->photo)): ?>
                            <img src="<?php echo e(asset('contents/admin/uploads/' . $data->photo)); ?>"
                                style="height:100; " alt="Profile Picture">
                            <?php else: ?>
                            <img src="<?php echo e(asset('contents/admin/images/avatar.png')); ?>" 
                            style="height:100; " alt="Profile Picture">
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="card-footer text-center">
                    <button type="submit" class="btn btn-sm btn-dark">Update Info</button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project_Onirban\resources\views/admin/user/edit.blade.php ENDPATH**/ ?>